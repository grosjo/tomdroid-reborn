Tomdroid Reborn
=============

What is this?
-------------

This project is a fork from abandonned Tomdroid project (github.com/tomboy-notes/tomdroid), to provide an up-to-date and maintained app


Compiling
---------

This project is made under Android Studio


Status
------
- Cleaning work of old and deprecated code

Debugging/Support
-----------------

Please submit requests/bugs via the [GitHub issue tracker](https://github.com/grosjo/tomdroid-reborn/issues).



Thanks
------

Thank you to Olivier Bilodeau <olivier@bottomlesspit.org> and Stefan Hammer <j.4@gmx.at> for their code on github
